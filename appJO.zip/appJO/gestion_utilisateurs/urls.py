from django.urls import path
from . import views
from .views import billet_list, billet_detail
 # Importez votre vue 'accueil'
from .views import client_list


urlpatterns = [
    path('inscription/', views.inscription, name='inscription'),
    path('profil/', views.profil, name='profil'),
    path('connexion/', views.connexion, name='connexion'),
    path('deconnexion/', views.deconnexion, name='deconnexion'),
     path('billets/', billet_list, name='billet_list'),
    path('billets/<int:billet_id>/', billet_detail, name='billet_detail'),
    
    path('clients/', client_list, name='client_list'),
]
