from django.contrib import admin
from .models import Utilisateur, Client, Panier, Billet

admin.site.register(Utilisateur)
admin.site.register(Client)
admin.site.register(Panier)
admin.site.register(Billet)
