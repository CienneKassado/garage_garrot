from django.db import models
from django.contrib.auth.models import User

class Administrateur(models.Model):
    administrateur_id = models.AutoField(primary_key=True)
    identifiant = models.CharField(max_length=50, unique=True)
    mot_de_passe = models.CharField(max_length=255)

class Utilisateur(models.Model):
    utilisateur_id = models.AutoField(primary_key=True)
    nom_utilisateur = models.CharField(max_length=50)
    mot_de_passe = models.CharField(max_length=255)
    clef_compte = models.CharField(max_length=255)

class Client(models.Model):
    client_id = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    adresse_email = models.EmailField(unique=True)

class Panier(models.Model):
    panier_id = models.AutoField(primary_key=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    offre = models.ForeignKey('gestion_offres.Offre', on_delete=models.CASCADE)

class Billet(models.Model):
    billet_id = models.AutoField(primary_key=True)
    utilisateur = models.ForeignKey(Utilisateur, on_delete=models.CASCADE)
    offre = models.ForeignKey('gestion_offres.Offre', on_delete=models.CASCADE)
    transaction_id = models.IntegerField()
    clef_billet = models.CharField(max_length=255)
    qr_code = models.CharField(max_length=255)
    statut_securite = models.BooleanField()
    etat_paiement = models.CharField(max_length=50)
    date_vente = models.DateTimeField()

    def __str__(self):
        return f"Billet {self.BilletID}"
