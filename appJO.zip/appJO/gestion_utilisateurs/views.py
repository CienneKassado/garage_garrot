from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Utilisateur
from .forms import UserRegistrationForm
from django.http import HttpResponse 
from .models import Client

def inscription(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Connecte automatiquement l'utilisateur après l'inscription
            login(request, user)
            messages.success(request, 'Inscription réussie.')
            return redirect('profil')
    else:
        form = UserRegistrationForm()
    return render(request, 'gestion_utilisateurs/inscription.html', {'form': form})

@login_required
def profil(request):
    return render(request, 'gestion_utilisateurs/profil.html')

def connexion(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, 'Connexion réussie.')
            return redirect('profil')
        else:
            messages.error(request, 'Identifiant ou mot de passe incorrect.')
    return render(request, 'gestion_utilisateurs/connexion.html')

@login_required
def deconnexion(request):
    logout(request)
    messages.info(request, 'Déconnexion réussie.')
    return redirect('accueil')

# gestion_utilisateurs/views.py
from django.shortcuts import render
from django.http import HttpResponse

def billet_list(request):
    return HttpResponse("Liste des billets")

def billet_detail(request, billet_id):
    return HttpResponse(f"Detail du billet {billet_id}")
# gestion_utilisateurs/views.py ou gestion_offres/views.py
from django.shortcuts import render


def client_list(request):
    clients = Client.objects.all()
    return render(request, 'gestion_utilisateurs/client_list.html', {'clients': clients})