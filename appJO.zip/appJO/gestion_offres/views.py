from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Offre


def liste_offres(request):
    offres = Offre.objects.all()
    return render(request, 'gestion_offres/liste_offres.html', {'offres': offres})

def detail_offre(request, offre_id):
    offre = get_object_or_404(Offre, pk=offre_id)
    return render(request, 'gestion_offres/detail_offre.html', {'offre': offre})

class OffreListView(ListView):
    model = Offre
    template_name = 'gestion_offres/offre_list.html'
    context_object_name = 'offres'

class OffreDetailView(DetailView):
    model = Offre
    template_name = 'gestion_offres/offre_detail.html'
    context_object_name = 'offre'

class OffreCreateView(CreateView):
    model = Offre
    template_name = 'gestion_offres/offre_form.html'
    fields = ['type', 'nombre_personne', 'prix', 'description', 'date_debut', 'date_fin']

class OffreUpdateView(UpdateView):
    model = Offre
    template_name = 'gestion_offres/offre_form.html'
    fields = ['type', 'nombre_personne', 'prix', 'description', 'date_debut', 'date_fin']

class OffreDeleteView(DeleteView):
    model = Offre
    template_name = 'gestion_offres/offre_confirm_delete.html'
    success_url = reverse_lazy('liste_offres')  # Redirige vers la liste des offres après la suppression



# gestion_offres/views.py
from django.shortcuts import render
from django.http import HttpResponse

def offre_list(request):
    return HttpResponse("Liste des offres")

def offre_detail(request, offre_id):
    return HttpResponse(f"Detail de l'offre {offre_id}")
