# gestion_offres/urls.py
from django.urls import path
from .views import offre_list, offre_detail

urlpatterns = [
    path('offres/', offre_list, name='offre_list'),
    path('offres/<int:offre_id>/', offre_detail, name='offre_detail'),
]
