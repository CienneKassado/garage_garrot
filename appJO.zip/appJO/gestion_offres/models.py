from django.db import models

class Offre(models.Model):
    offre_id = models.AutoField(primary_key=True)
    type = models.CharField(max_length=50)
    nombre_personne = models.IntegerField()
    prix = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    date_debut = models.DateField()
    date_fin = models.DateField()
