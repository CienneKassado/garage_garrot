from django.contrib import admin
from .models import Offre

admin.site.register(Offre)
# Ajoutez d'autres enregistrements si vous avez plus de modèles
